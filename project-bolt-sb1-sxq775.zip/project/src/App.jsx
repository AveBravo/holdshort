import React from 'react';
import { NextUIProvider } from '@nextui-org/react';
import { ThemeProvider as NextThemesProvider } from 'next-themes';
import MainMenu from './components/MainMenu';
import DashboardPage from './components/DashboardPage';
import LocationsPage from './components/LocationsPage';
import OrganizationPage from './components/OrganizationPage';
import OrganizationSettings from './components/OrganizationSettings';
import CalendarPage from './components/CalendarPage';
import HeroSection from './components/HeroSection';
import HowItWorks from './components/HowItWorks';
import SchedulingFeatures from './components/SchedulingFeatures';
import FeaturesSection from './components/FeaturesSection';
import AccountFeatures from './components/AccountFeatures';
import MobileAppPromo from './components/MobileAppPromo';
import ImageCarousel from './components/ImageCarousel';
import PricingSection from './components/PricingSection';

function HomePage() {
  return (
    <>
      <HeroSection />
      <HowItWorks />
      <SchedulingFeatures />
      <FeaturesSection />
      <AccountFeatures />
      <MobileAppPromo />
      <ImageCarousel />
      <PricingSection />
    </>
  );
}

export default function App() {
  const [route, setRoute] = React.useState({ page: 'home' });

  const renderPage = () => {
    switch (route.page) {
      case 'dashboard':
        return <DashboardPage onNavigate={setRoute} />;
      case 'locations':
        return <LocationsPage />;
      case 'organization':
        return <OrganizationPage onNavigate={setRoute} />;
      case 'organization-settings':
        return <OrganizationSettings onNavigate={setRoute} />;
      case 'calendar-month':
      case 'calendar-week':
      case 'calendar-resources':
        return <CalendarPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <NextUIProvider>
      <NextThemesProvider attribute="class" defaultTheme="light">
        <div className="min-h-screen bg-background">
          <MainMenu onNavigate={setRoute} />
          {renderPage()}
        </div>
      </NextThemesProvider>
    </NextUIProvider>
  );
}