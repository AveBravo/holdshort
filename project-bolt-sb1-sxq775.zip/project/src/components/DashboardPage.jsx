import React from 'react';
import { Card, CardBody, CardHeader, Progress, Button, Avatar, Chip } from '@nextui-org/react';
import { AlertTriangle, Calendar, Clock, FileText, Users, Plane, MapPin, ChevronRight } from 'lucide-react';

const notifications = [
  { id: 1, type: 'warning', message: 'Your FAA Flight Review expired on 31 Aug, 2016' },
  { id: 2, type: 'warning', message: 'Your "JetSuite" Organization Flight Review expired on 17 Dec, 2020' },
  { id: 3, type: 'warning', message: 'Your Instructor Certificate 1233232 expired on 17 Sep, 2015' },
  { id: 4, type: 'warning', message: 'Your Medical Certificate expired on 31 May, 2016' },
];

const organizations = [
  { id: 1, name: 'JetSuite', role: 'Owner, Member', status: 'active' },
  { id: 2, name: 'Blue Horizon', role: 'Owner, Member, Instructor', status: 'overdue' },
  { id: 3, name: 'Test 1588', role: 'Owner, Member', status: 'overdue' },
];

const upcomingEvents = [
  { id: 1, title: 'Flight Training', time: '09:00 AM', date: 'Today', instructor: 'John Smith' },
  { id: 2, title: 'Ground School', time: '02:00 PM', date: 'Tomorrow', instructor: 'Sarah Johnson' },
];

export default function DashboardPage({ onNavigate }) {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Personal Info Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="col-span-1">
          <CardBody className="flex flex-col items-center text-center gap-4">
            <Avatar
              src="https://i.pravatar.cc/150?img=3"
              className="w-24 h-24"
            />
            <div>
              <h2 className="text-xl font-bold">Holdshort Administrator</h2>
              <p className="text-sm text-gray-500">note@holdshort.com</p>
              <p className="text-sm text-gray-500">380634415007</p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" color="primary">Edit Profile</Button>
              <Button size="sm" variant="bordered">Documents</Button>
            </div>
          </CardBody>
        </Card>

        {/* Notifications Card */}
        <Card className="col-span-1 md:col-span-2">
          <CardHeader className="flex gap-3">
            <AlertTriangle className="w-6 h-6 text-warning" />
            <div className="flex flex-col">
              <p className="text-lg font-bold">Important Notifications</p>
              <p className="text-small text-default-500">Review your expired documents</p>
            </div>
          </CardHeader>
          <CardBody>
            <div className="space-y-3">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className="flex items-start gap-2 p-2 rounded-lg bg-warning-50 dark:bg-warning-900/20"
                >
                  <AlertTriangle className="w-4 h-4 text-warning mt-1 flex-shrink-0" />
                  <p className="text-sm">{notification.message}</p>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Organizations and Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-1 md:col-span-2">
          <CardHeader className="flex gap-3">
            <Users className="w-6 h-6" />
            <div className="flex flex-col">
              <p className="text-lg font-bold">My Organizations</p>
              <p className="text-small text-default-500">Organizations you're a member of</p>
            </div>
          </CardHeader>
          <CardBody>
            <div className="space-y-4">
              {organizations.map((org) => (
                <Button
                  key={org.id}
                  className="w-full"
                  variant="light"
                  onPress={() => onNavigate({ page: 'organization', params: { id: org.id.toString() } })}
                >
                  <div className="flex items-center justify-between w-full p-3">
                    <div className="flex items-center gap-3">
                      <Avatar
                        name={org.name}
                        size="sm"
                      />
                      <div>
                        <p className="font-semibold">{org.name}</p>
                        <p className="text-xs text-default-500">Roles: {org.role}</p>
                      </div>
                    </div>
                    <Chip
                      color={org.status === 'active' ? 'success' : 'warning'}
                      size="sm"
                    >
                      {org.status}
                    </Chip>
                  </div>
                </Button>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card className="col-span-1">
          <CardHeader className="flex gap-3">
            <Calendar className="w-6 h-6" />
            <div className="flex flex-col">
              <p className="text-lg font-bold">Upcoming Events</p>
              <p className="text-small text-default-500">Your next activities</p>
            </div>
          </CardHeader>
          <CardBody>
            <div className="space-y-4">
              {upcomingEvents.map((event) => (
                <div
                  key={event.id}
                  className="p-3 rounded-lg border border-default-200"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-default-500" />
                    <span className="text-sm">{event.time} - {event.date}</span>
                  </div>
                  <p className="font-semibold">{event.title}</p>
                  <p className="text-sm text-default-500">with {event.instructor}</p>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}