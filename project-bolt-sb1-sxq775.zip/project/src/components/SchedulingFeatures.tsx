import React from 'react';
import { Card, CardBody, Image, Button, Tabs, Tab } from '@nextui-org/react';
import { Plane, Shield, CreditCard } from 'lucide-react';

const features = [
  {
    title: "Compliance",
    icon: <Shield className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1540962351504-03099e0a754b?auto=format&fit=crop&w=1200&q=80",
    description: "Our aircraft scheduling software offers comprehensive enforcement capabilities including Certificates, Ratings, FAA Flight Review, Medical, Organization Review, and Renter's Insurance verification. The integrated tach & meter tracking system automatically notifies you of upcoming maintenance inspections.",
    imageAlt: "Aircraft maintenance hangar with multiple planes"
  },
  {
    title: "Versatility",
    icon: <Plane className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1556388158-158ea5ccacbd?auto=format&fit=crop&w=1200&q=80",
    description: "Experience multi-tier role management with fully customizable resource distribution between managers, instructors, pilots, and students. Beyond standard aircraft and instructor scheduling, add custom resources like equipment and staff for complete operational control.",
    imageAlt: "Aircraft model with globe"
  },
  {
    title: "Invoicing",
    icon: <CreditCard className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1200&q=80",
    description: "Integrated with Stripe.com for secure payment processing, our system enables comprehensive invoice management for flights and products. Combined with our scheduling features, it creates an all-in-one solution for your flight operations.",
    imageAlt: "Payment terminal"
  }
];

export default function SchedulingFeatures() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-24">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          Scheduling & Aircraft Management System Features
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
          Streamline your aviation operations with our comprehensive management system
        </p>
      </div>

      <Tabs 
        aria-label="Features" 
        color="primary"
        variant="bordered"
        classNames={{
          tabList: "gap-6",
          tab: "h-14",
          cursor: "bg-primary",
          tabContent: "group-data-[selected=true]:text-white",
          panel: "overflow-visible pt-6"
        }}
      >
        {features.map((feature, index) => (
          <Tab
            key={index}
            title={
              <div className="flex items-center space-x-2">
                <div className="text-default-500 group-data-[selected=true]:text-white">{feature.icon}</div>
                <span>{feature.title}</span>
              </div>
            }
          >
            <Card>
              <CardBody>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="relative h-[400px]">
                    <Image
                      isBlurred
                      src={feature.image}
                      alt={feature.imageAlt}
                      radius="lg"
                      classNames={{
                        wrapper: "w-full h-full",
                        img: "object-cover w-full h-full"
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent rounded-lg" />
                    <h3 className="absolute top-6 left-6 text-2xl font-bold text-white">
                      {feature.title}
                    </h3>
                  </div>
                  <div className="flex flex-col justify-center">
                    <p className="text-lg leading-relaxed">
                      {feature.description}
                    </p>
                    <Button
                      color="primary"
                      className="mt-6 w-fit"
                    >
                      Learn More
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          </Tab>
        ))}
      </Tabs>
    </div>
  );
}