import React from 'react';
import { Card, CardBody, CardHeader, Button, Chip } from '@nextui-org/react';
import { Check, Plane, Users, Building2 } from 'lucide-react';

const plans = [
  {
    name: "Shared Plane",
    icon: <Plane className="w-6 h-6" />,
    price: "$10.00",
    yearlyPrice: "$110",
    color: "text-green-500",
    borderColor: "group-hover:border-green-500",
    features: {
      resources: "1 Aircraft & Other Resource",
      users: "Unlimited Instructors, Pilots & Users",
      locations: "1 Location (Airport, Office, etc.)",
    },
    savings: "$10.00",
    popular: false
  },
  {
    name: "Flying Club",
    icon: <Users className="w-6 h-6" />,
    price: "$30.00",
    yearlyPrice: "$330",
    color: "text-blue-500",
    borderColor: "group-hover:border-blue-500",
    features: {
      resources: "Up to 5 Aircraft & Other Resources",
      users: "Unlimited Instructors, Pilots & Users",
      locations: "1 Location (Airport, Office, etc.)",
    },
    savings: "$30.00",
    popular: true
  },
  {
    name: "Flight School",
    icon: <Plane className="w-6 h-6" />,
    price: "$55.00",
    yearlyPrice: "$605",
    color: "text-amber-500",
    borderColor: "group-hover:border-amber-500",
    features: {
      resources: "Up to 10 Aircraft & Other Resources",
      users: "Unlimited Instructors, Pilots & Users",
      locations: "Up to 2 Locations (Airport, Office, etc.)",
    },
    savings: "$55.00",
    popular: false
  },
  {
    name: "Enterprise",
    icon: <Building2 className="w-6 h-6" />,
    price: "$499.00",
    yearlyPrice: "$5489",
    color: "text-pink-500",
    borderColor: "group-hover:border-pink-500",
    features: {
      resources: "Unlimited Aircraft & Other Resources",
      users: "Unlimited Instructors, Pilots & Users",
      locations: "Unlimited Locations (Airport, Office, etc.)",
    },
    savings: "$499.00",
    popular: false
  }
];

export default function PricingSection() {
  const [isYearly, setIsYearly] = React.useState(false);

  return (
    <div className="bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">
            Choose the perfect plan for your aviation needs
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4">
            <span className={`text-sm ${!isYearly ? 'text-primary font-semibold' : 'text-gray-600'}`}>
              Monthly billing
            </span>
            <Button
              className="min-w-[64px]"
              color="primary"
              radius="full"
              variant={isYearly ? "flat" : "solid"}
              onPress={() => setIsYearly(!isYearly)}
            >
              {isYearly ? "Yearly" : "Monthly"}
            </Button>
            <span className={`text-sm ${isYearly ? 'text-primary font-semibold' : 'text-gray-600'}`}>
              Yearly billing
            </span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`group border-2 border-transparent transition-all ${plan.borderColor} ${
                plan.popular ? 'scale-105' : ''
              }`}
            >
              <CardHeader className="flex gap-3 p-6">
                <div className={`p-2 rounded-lg ${plan.color} bg-opacity-10`}>
                  {plan.icon}
                </div>
                <div className="flex flex-col">
                  <p className="text-lg font-semibold">{plan.name}</p>
                  {plan.popular && (
                    <Chip color="primary" size="sm" variant="flat">
                      Most Popular
                    </Chip>
                  )}
                </div>
              </CardHeader>
              <CardBody className="px-6 py-2 space-y-6">
                <div className="space-y-2">
                  <p className="text-4xl font-bold">
                    {isYearly ? plan.yearlyPrice : plan.price}
                  </p>
                  <p className="text-sm text-gray-500">
                    per {isYearly ? 'year' : 'month'}
                  </p>
                </div>

                <div className="space-y-4">
                  {Object.entries(plan.features).map(([key, value]) => (
                    <div key={key} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                      <span className="text-sm">{value}</span>
                    </div>
                  ))}
                </div>

                <Button
                  color="primary"
                  size="lg"
                  className="w-full"
                  variant={plan.popular ? "solid" : "bordered"}
                >
                  Sign In & Buy now!
                </Button>

                {isYearly && (
                  <p className="text-sm text-center text-success">
                    Save {plan.savings} with yearly billing
                  </p>
                )}
              </CardBody>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}