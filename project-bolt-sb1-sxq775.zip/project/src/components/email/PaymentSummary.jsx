import React from 'react';
import { Card, CardBody, Button, Divider } from '@nextui-org/react';

export default function PaymentSummary({ summary, paymentStatus, paymentInfo }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
      <Card>
        <CardBody>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Original Sum</span>
              <span>${summary.originalSum}</span>
            </div>
            <div className="flex justify-between">
              <span>Discount</span>
              <span>${summary.discount}</span>
            </div>
            <div className="flex justify-between">
              <span>Tax</span>
              <span>${summary.tax}</span>
            </div>
            <div className="flex justify-between font-bold">
              <span>Total</span>
              <span>${summary.total}</span>
            </div>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Payment Status:</span>
              <span className="text-warning font-semibold">{paymentStatus}</span>
            </div>
            <Divider />
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-default-500">Organization:</span>
                <span className="font-medium">{paymentInfo.organization}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-default-500">Invoice Date:</span>
                <span className="font-medium">{paymentInfo.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-default-500">Pilot Name:</span>
                <span className="font-medium">{paymentInfo.pilotName}</span>
              </div>
            </div>
            <Button color="primary" className="w-full">
              Pay Now
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}