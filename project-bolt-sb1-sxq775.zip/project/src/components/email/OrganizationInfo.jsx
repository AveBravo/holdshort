import React from 'react';
import { Card, CardBody } from '@nextui-org/react';

export default function OrganizationInfo({ organization }) {
  const fields = [
    { label: 'Organization', value: organization.name },
    { label: 'Phone', value: organization.phone },
    { label: 'Fax', value: organization.fax },
    { label: 'Email', value: organization.email },
    { label: 'Country', value: organization.country },
    { label: 'Address', value: organization.address },
    { label: 'City', value: organization.city },
    { label: 'State/Province', value: organization.state },
    { label: 'Zip', value: organization.zip }
  ];

  return (
    <Card className="my-4">
      <CardBody>
        <div className="grid grid-cols-[auto_1fr] gap-x-8 gap-y-2">
          {fields.map((field, index) => (
            <React.Fragment key={index}>
              <span className="text-default-500 text-right whitespace-nowrap">{field.label}:</span>
              <span className="font-medium">{field.value}</span>
            </React.Fragment>
          ))}
        </div>
      </CardBody>
    </Card>
  );
}