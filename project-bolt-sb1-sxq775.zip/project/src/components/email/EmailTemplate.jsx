import React from 'react';
import EmailHeader from './EmailHeader';
import OrganizationInfo from './OrganizationInfo';
import ResourceTable from './ResourceTable';
import PaymentSummary from './PaymentSummary';
import EmailFooter from './EmailFooter';

const sampleData = {
  organization: {
    name: 'JetSuite',
    phone: '+38011111111',
    fax: '+38011111111',
    email: 'test.memcrab@holdshort.com',
    country: 'United States',
    address: 'suite 11',
    city: '-',
    state: 'California',
    zip: '234sdfsf'
  },
  resources: [
    {
      type: 'Aircraft',
      model: 'N11QZ',
      time: '10.00 0.00',
      qty: '1.00',
      rate: '450',
      discount: '0',
      salesTax: '0',
      taxable: 'no',
      total: '450'
    }
  ],
  summary: {
    originalSum: 450,
    discount: 0,
    tax: 0,
    total: 450
  },
  paymentInfo: {
    status: 'Unpaid',
    organization: 'JetSuite',
    date: '6 Nov, 2024',
    pilotName: 'Evheniy Askarov'
  }
};

export default function EmailTemplate() {
  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <EmailHeader />
      
      <div className="text-xl font-semibold">
        Welcome to Holdshort!
      </div>
      
      <OrganizationInfo organization={sampleData.organization} />
      
      <ResourceTable resources={sampleData.resources} />
      
      <PaymentSummary 
        summary={sampleData.summary}
        paymentStatus={sampleData.paymentInfo.status}
        paymentInfo={sampleData.paymentInfo}
      />
      
      <EmailFooter />
    </div>
  );
}