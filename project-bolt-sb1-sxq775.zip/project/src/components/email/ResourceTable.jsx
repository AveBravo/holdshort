import React from 'react';
import { Table, TableHeader, TableBody, TableColumn, TableRow, TableCell } from '@nextui-org/react';

export default function ResourceTable({ resources }) {
  return (
    <Table aria-label="Resource details" className="my-4">
      <TableHeader>
        <TableColumn>Resources</TableColumn>
        <TableColumn>Time</TableColumn>
        <TableColumn>QTY</TableColumn>
        <TableColumn>Rate, $</TableColumn>
        <TableColumn>Discount, %</TableColumn>
        <TableColumn>Sales Tax, %</TableColumn>
        <TableColumn>Taxable</TableColumn>
        <TableColumn>Total</TableColumn>
      </TableHeader>
      <TableBody>
        {resources.map((resource, index) => (
          <TableRow key={index}>
            <TableCell>{`${resource.type} ${resource.model}`}</TableCell>
            <TableCell>{resource.time}</TableCell>
            <TableCell>{resource.qty}</TableCell>
            <TableCell>{resource.rate}</TableCell>
            <TableCell>{resource.discount}</TableCell>
            <TableCell>{resource.salesTax}</TableCell>
            <TableCell>{resource.taxable}</TableCell>
            <TableCell>${resource.total}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}