import React from 'react';
import { Card, CardBody } from '@nextui-org/react';

export default function EmailFooter() {
  return (
    <Card className="mt-8">
      <CardBody>
        <div className="text-center space-y-4">
          <p className="text-default-500">Regards,</p>
          <p className="font-semibold">Holdshort Team</p>
          <div className="pt-4 border-t text-sm text-default-400">
            <div className="flex justify-center gap-4">
              <a href="#" className="text-primary">Terms</a>
              <span>|</span>
              <a href="#" className="text-primary">Privacy</a>
            </div>
          </div>
        </div>
      </CardBody>
    </Card>
  );
}