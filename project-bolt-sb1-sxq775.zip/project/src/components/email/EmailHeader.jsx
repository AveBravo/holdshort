import React from 'react';
import { Card, CardBody } from '@nextui-org/react';

export default function EmailHeader() {
  return (
    <Card className="bg-primary">
      <CardBody className="py-3">
        <div className="flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <img 
              src="https://holdshort.com/public/images/logo-holdshort.svg" 
              alt="HoldShort Logo" 
              className="h-8"
            />
            <span className="text-xl font-semibold">Holdshort</span>
          </div>
          <div className="flex gap-4">
            <a href="#" className="text-white hover:text-white/80">Twitter</a>
            <a href="#" className="text-white hover:text-white/80">Facebook</a>
            <a href="#" className="text-white hover:text-white/80">Youtube</a>
          </div>
        </div>
      </CardBody>
    </Card>
  );
}