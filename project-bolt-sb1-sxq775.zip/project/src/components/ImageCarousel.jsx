import React from 'react';
import { Card, CardBody, Image, Button, Tabs, Tab } from '@nextui-org/react';
import { ChevronLeft, ChevronRight, Monitor, Smartphone } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const screenshots = {
  web: [
    {
      url: "https://images.unsplash.com/photo-1522199755839-a2bacb67c546?auto=format&fit=crop&w=2400&q=80",
      alt: "Dashboard view showing flight scheduling calendar",
      title: "Intuitive Scheduling Dashboard"
    },
    {
      url: "https://images.unsplash.com/photo-1580716937094-a899b4e21666?auto=format&fit=crop&w=2400&q=80",
      alt: "Aircraft management interface",
      title: "Aircraft Fleet Management"
    },
    {
      url: "https://images.unsplash.com/photo-1559028012-481c04fa702d?auto=format&fit=crop&w=2400&q=80",
      alt: "Pilot profile and certifications page",
      title: "Pilot Certification Tracking"
    },
    {
      url: "https://images.unsplash.com/photo-1436473849883-bb3464c23e93?auto=format&fit=crop&w=2400&q=80",
      alt: "Flight planning interface",
      title: "Advanced Flight Planning"
    },
    {
      url: "https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=2400&q=80",
      alt: "Analytics dashboard",
      title: "Performance Analytics"
    }
  ],
  app: [
    {
      url: "https://images.unsplash.com/photo-1626863905121-3b0c0ed7b94c?auto=format&fit=crop&w=2400&q=80",
      alt: "Mobile app flight booking screen",
      title: "Mobile Flight Booking"
    },
    {
      url: "https://images.unsplash.com/photo-1452421822248-d4c2b47f0c81?auto=format&fit=crop&w=2400&q=80",
      alt: "Mobile checklist interface",
      title: "Digital Checklists"
    },
    {
      url: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=2400&q=80",
      alt: "Weather briefing mobile view",
      title: "Weather Updates"
    },
    {
      url: "https://images.unsplash.com/photo-1517960413843-0aee8e2b3285?auto=format&fit=crop&w=2400&q=80",
      alt: "Flight tracking screen",
      title: "Real-time Flight Tracking"
    },
    {
      url: "https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=2400&q=80",
      alt: "Maintenance logging screen",
      title: "Maintenance Logging"
    }
  ]
};

export default function ImageCarousel() {
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const [direction, setDirection] = React.useState(0);
  const [loaded, setLoaded] = React.useState({});
  
  const getImagesToShow = () => {
    if (typeof window === 'undefined') return 3;
    if (window.innerWidth < 640) return 1;
    if (window.innerWidth < 1024) return 2;
    return 3;
  };
  
  const [imagesToShow, setImagesToShow] = React.useState(getImagesToShow());

  React.useEffect(() => {
    const handleResize = () => {
      setImagesToShow(getImagesToShow());
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handlePrevious = (images) => {
    setDirection(-1);
    setCurrentIndex(current => 
      current === 0 ? images.length - imagesToShow : current - 1
    );
  };

  const handleNext = (images) => {
    setDirection(1);
    setCurrentIndex(current => 
      current + imagesToShow >= images.length ? 0 : current + 1
    );
  };

  const handleImageLoad = (url) => {
    setLoaded(prev => ({ ...prev, [url]: true }));
  };

  const CarouselContent = ({ images }) => {
    const visibleImages = images.slice(currentIndex, currentIndex + imagesToShow);
    
    if (visibleImages.length < imagesToShow) {
      visibleImages.push(...images.slice(0, imagesToShow - visibleImages.length));
    }

    return (
      <div className="relative px-4 sm:px-12">
        {/* Navigation Buttons */}
        <Button
          isIconOnly
          size="lg"
          className="absolute -left-2 sm:left-0 top-1/2 -translate-y-1/2 bg-primary/90 hover:bg-primary z-10 shadow-xl"
          onClick={() => handlePrevious(images)}
        >
          <ChevronLeft className="w-6 h-6 text-white" />
        </Button>
        <Button
          isIconOnly
          size="lg"
          className="absolute -right-2 sm:right-0 top-1/2 -translate-y-1/2 bg-primary/90 hover:bg-primary z-10 shadow-xl"
          onClick={() => handleNext(images)}
        >
          <ChevronRight className="w-6 h-6 text-white" />
        </Button>

        {/* Images Grid */}
        <AnimatePresence initial={false} mode="wait">
          <motion.div
            key={currentIndex}
            custom={direction}
            initial={{ opacity: 0, x: direction > 0 ? 100 : -100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction > 0 ? -100 : 100 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className={`grid gap-4 ${
              imagesToShow === 1 ? 'grid-cols-1' :
              imagesToShow === 2 ? 'grid-cols-2' :
              'grid-cols-3'
            }`}
          >
            {visibleImages.map((image, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: loaded[image.url] ? 1 : 0, y: loaded[image.url] ? 0 : 20 }}
                transition={{ duration: 0.3, delay: idx * 0.1 }}
                className="min-h-[300px] sm:min-h-[400px]"
              >
                <Card className="w-full h-full">
                  <CardBody className="p-0 overflow-hidden">
                    <div className="relative w-full h-full group">
                      <div className="absolute inset-0 bg-default-100 animate-pulse" 
                           style={{ display: loaded[image.url] ? 'none' : 'block' }} />
                      <Image
                        src={image.url}
                        alt={image.alt}
                        radius="none"
                        onLoad={() => handleImageLoad(image.url)}
                        classNames={{
                          wrapper: "w-full h-full",
                          img: `object-cover w-full h-full brightness-90 group-hover:scale-105 transition-transform duration-500 ${
                            loaded[image.url] ? 'opacity-100' : 'opacity-0'
                          }`
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
                      
                      <div className="absolute bottom-0 inset-x-0 p-4">
                        <h3 className="text-base sm:text-lg font-bold text-white drop-shadow-md">
                          {image.title}
                        </h3>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Navigation Dots */}
        <div className="flex gap-2 justify-center mt-6">
          {Array.from({ length: Math.ceil(images.length / imagesToShow) }).map((_, index) => (
            <motion.button
              key={index}
              className={`h-2 rounded-full transition-all ${
                Math.floor(currentIndex / imagesToShow) === index 
                  ? "bg-primary w-6" 
                  : "bg-gray-300 dark:bg-gray-600 hover:bg-primary/50 w-2"
              }`}
              onClick={() => {
                const newIndex = index * imagesToShow;
                setDirection(newIndex > currentIndex ? 1 : -1);
                setCurrentIndex(newIndex);
              }}
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.1 }}
            />
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 sm:py-24 space-y-8">
      <div className="text-center">
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
          Experience Our Platform
        </h2>
        <p className="text-base sm:text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
          Take a tour of our intuitive interfaces, designed for both web and mobile experiences
        </p>
      </div>

      <Tabs 
        aria-label="Platform Screenshots"
        color="primary"
        variant="bordered"
        classNames={{
          tabList: "gap-4 sm:gap-6",
          tab: "h-12 sm:h-14",
          cursor: "bg-primary",
          tabContent: "group-data-[selected=true]:text-white"
        }}
        onSelectionChange={() => {
          setCurrentIndex(0);
          setDirection(0);
        }}
      >
        <Tab
          key="web"
          title={
            <div className="flex items-center space-x-2">
              <Monitor className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>Web Platform</span>
            </div>
          }
        >
          <CarouselContent images={screenshots.web} />
        </Tab>
        <Tab
          key="app"
          title={
            <div className="flex items-center space-x-2">
              <Smartphone className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>Mobile App</span>
            </div>
          }
        >
          <CarouselContent images={screenshots.app} />
        </Tab>
      </Tabs>
    </div>
  );
}