import React from 'react';
import {
  Navbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  Button,
  Avatar,
  Dropdown,
  DropdownTrigger,
  DropdownMenu,
  DropdownItem,
  Switch
} from '@nextui-org/react';
import {
  Calendar,
  PlusCircle,
  Search,
  UserCircle,
  BellRing,
  Moon,
  Sun,
  LayoutDashboard,
  MapPin,
  LogOut,
  Settings,
  HelpCircle,
  BarChart
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { Route } from '../App';

interface MainMenuProps {
  onNavigate: (route: Route) => void;
}

export default function MainMenu({ onNavigate }: MainMenuProps) {
  const { theme, setTheme } = useTheme();
  const [isSelected, setIsSelected] = React.useState(false);

  return (
    <Navbar 
      maxWidth="full" 
      className="bg-background shadow-sm"
      classNames={{
        wrapper: "px-4",
      }}
    >
      <NavbarBrand>
        <Button
          variant="light"
          onPress={() => onNavigate({ page: 'home' })}
        >
          <img 
            src="https://holdshort.com/public/images/logo-holdshort.svg" 
            alt="HoldShort Logo" 
            className="h-8"
          />
        </Button>
      </NavbarBrand>

      <NavbarContent className="hidden sm:flex gap-4" justify="center">
        <NavbarItem>
          <Button
            variant="light"
            startContent={<LayoutDashboard className="w-4 h-4" />}
            onPress={() => onNavigate({ page: 'dashboard' })}
          >
            Dashboard
          </Button>
        </NavbarItem>
        <NavbarItem>
          <Button
            variant="light"
            startContent={<Calendar className="w-4 h-4" />}
          >
            Calendars
          </Button>
        </NavbarItem>
        <NavbarItem>
          <Button
            variant="light"
            startContent={<MapPin className="w-4 h-4" />}
            onPress={() => onNavigate({ page: 'locations' })}
          >
            Locations
          </Button>
        </NavbarItem>
        <NavbarItem>
          <Button
            variant="light"
            startContent={<PlusCircle className="w-4 h-4" />}
          >
            Add Event
          </Button>
        </NavbarItem>
        <NavbarItem>
          <Button
            variant="light"
            startContent={<Search className="w-4 h-4" />}
          >
            Search
          </Button>
        </NavbarItem>
      </NavbarContent>

      <NavbarContent justify="end">
        <NavbarItem>
          <Switch
            defaultSelected={theme === 'dark'}
            size="lg"
            color="secondary"
            startContent={<Sun />}
            endContent={<Moon />}
            onChange={(e) => setTheme(e.target.checked ? 'dark' : 'light')}
          />
        </NavbarItem>
        <NavbarItem>
          <Button
            variant="light"
            isIconOnly
            radius="full"
            aria-label="Notifications"
          >
            <BellRing className="w-5 h-5" />
          </Button>
        </NavbarItem>
        <NavbarItem>
          <Dropdown placement="bottom-end">
            <DropdownTrigger>
              <Avatar
                as="button"
                className="transition-transform"
                color="primary"
                name="User"
                size="sm"
                icon={<UserCircle className="w-6 h-6" />}
              />
            </DropdownTrigger>
            <DropdownMenu aria-label="Profile Actions" variant="flat">
              <DropdownItem key="profile" className="h-14 gap-2">
                <p className="font-semibold">Signed in as</p>
                <p className="font-semibold">user@example.com</p>
              </DropdownItem>
              <DropdownItem
                key="dashboard"
                startContent={<LayoutDashboard className="w-4 h-4" />}
                onPress={() => onNavigate({ page: 'dashboard' })}
              >
                Dashboard
              </DropdownItem>
              <DropdownItem
                key="settings"
                startContent={<Settings className="w-4 h-4" />}
              >
                My Settings
              </DropdownItem>
              <DropdownItem
                key="analytics"
                startContent={<BarChart className="w-4 h-4" />}
              >
                Analytics
              </DropdownItem>
              <DropdownItem
                key="help"
                startContent={<HelpCircle className="w-4 h-4" />}
              >
                Help & Feedback
              </DropdownItem>
              <DropdownItem
                key="logout"
                color="danger"
                startContent={<LogOut className="w-4 h-4" />}
              >
                Log Out
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </NavbarItem>
      </NavbarContent>
    </Navbar>
  );
}