import React from 'react';
import { Card, CardBody, Button, Image } from '@nextui-org/react';
import { ArrowRight } from 'lucide-react';

export default function AboutUs() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-24">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-violet-500 bg-clip-text text-transparent">
            Pioneering the Future of Flight Training
          </h2>
          
          <div className="space-y-4 text-lg text-gray-600 dark:text-gray-400">
            <p>
              Since 1970, HoldShort has been at the forefront of aviation education, 
              transforming how flight schools and aviation enthusiasts manage their operations.
            </p>
            
            <p>
              Our platform serves over 500+ flight schools worldwide, processing more than 
              100,000 flight bookings annually. We're committed to making aviation education 
              more accessible, efficient, and safer through innovative technology.
            </p>
            
            <p>
              What sets us apart is our deep understanding of aviation requirements and 
              our dedication to compliance and safety. Our team includes experienced pilots, 
              flight instructors, and software engineers who work together to create the 
              most comprehensive flight school management solution.
            </p>
          </div>

          <div className="flex gap-4 pt-4">
            <Button
              color="primary"
              endContent={<ArrowRight className="w-4 h-4" />}
              size="lg"
            >
              Learn Our Story
            </Button>
            <Button
              variant="bordered"
              size="lg"
            >
              Meet the Team
            </Button>
          </div>
        </div>

        <Card className="relative w-full aspect-[4/3]">
          <CardBody className="p-0 overflow-hidden">
            <div className="absolute inset-0 bg-blue-100 dark:bg-blue-900 blur-2xl opacity-30" />
            <Image
              isBlurred
              width={800}
              height={600}
              src="https://images.unsplash.com/photo-1559742811-822873691df8?auto=format&fit=crop&w=1600&q=80"
              alt="Flight instructor teaching a student pilot"
              classNames={{
                wrapper: "w-full h-full",
                img: "object-cover w-full h-full hover:scale-105 transition-transform duration-500"
              }}
            />
          </CardBody>
        </Card>
      </div>
    </div>
  );
}