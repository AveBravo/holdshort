import React from 'react';
import { Card, Button } from '@nextui-org/react';
import { Apple, Smartphone } from 'lucide-react';

export default function MobileAppPromo() {
  return (
    <div className="bg-primary overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Mobile App Preview */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-transparent opacity-50 md:hidden" />
            <img
              src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=1200&q=80"
              alt="Mobile app interface"
              className="rounded-3xl shadow-2xl mx-auto max-w-[300px] relative z-10"
            />
            {/* Decorative Elements */}
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
          </div>

          {/* Content */}
          <div className="relative z-10 text-white">
            <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
              Use our apps to{' '}
              <span className="text-white">schedule a plane</span>
              {' '}anytime, anywhere
            </h2>
            
            <p className="text-lg md:text-xl text-white/80 mb-8">
              For Flight Schools, Flying Clubs, FBOs, Aircraft Partnerships and General Aviation
            </p>

            <div className="flex flex-wrap gap-4">
              <Button
                size="lg"
                variant="bordered"
                className="text-white border-white"
                startContent={<Apple className="w-5 h-5" />}
              >
                Download on the App Store
              </Button>
              <Button
                size="lg"
                variant="bordered"
                className="text-white border-white"
                startContent={<Smartphone className="w-5 h-5" />}
              >
                Get it on Google Play
              </Button>
            </div>

            {/* Features List */}
            <div className="mt-12 grid grid-cols-2 gap-6">
              {[
                'Real-time Scheduling',
                'Flight Planning',
                'Maintenance Tracking',
                'Weather Updates'
              ].map((feature, index) => (
                <Card 
                  key={index}
                  className="bg-white/10 border-none"
                >
                  <div className="p-3 text-sm font-medium text-center">
                    {feature}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-blue-800 -z-10" />
    </div>
  );
}