import React from 'react';
import { Button, Card } from '@nextui-org/react';
import { Play, ArrowRight, Calendar, ChevronDown } from 'lucide-react';

export default function HeroSection() {
  return (
    <div className="relative min-h-[90vh] flex items-center">
      {/* Video Background */}
      <div className="absolute inset-0 overflow-hidden">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute min-w-full min-h-full object-cover"
        >
          <source
            src="https://static.videezy.com/system/resources/previews/000/044/479/original/Airplane-sunset.mp4"
            type="video/mp4"
          />
        </video>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
      </div>

      {/* Main Content */}
      <div className="relative max-w-7xl mx-auto px-4 py-24 grid md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight">
              Your Journey to the
              <span className="block bg-gradient-to-r from-blue-400 to-violet-400 bg-clip-text text-transparent">
                Skies Begins Here
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-xl">
              Experience world-class flight training with state-of-the-art aircraft and expert instructors.
              Start your aviation career today.
            </p>
          </div>

          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              color="primary"
              endContent={<Calendar className="w-4 h-4" />}
              className="font-semibold"
            >
              Schedule Trial Flight
            </Button>
            <Button
              size="lg"
              variant="bordered"
              className="text-white border-white font-semibold"
              endContent={<Play className="w-4 h-4" />}
            >
              Watch Our Story
            </Button>
          </div>

          <div className="flex items-center gap-6 text-gray-300">
            <div className="flex -space-x-4">
              {[1, 2, 3, 4].map((i) => (
                <img
                  key={i}
                  src={`https://i.pravatar.cc/150?img=${i + 10}`}
                  alt={`Student ${i}`}
                  className="w-10 h-10 rounded-full border-2 border-white"
                />
              ))}
            </div>
            <div>
              <p className="font-semibold">Join 500+ Student Pilots</p>
              <p className="text-sm">Who chose us for their training</p>
            </div>
          </div>
        </div>

        {/* Stats Card */}
        <div className="flex items-center justify-center">
          <Card className="bg-white/10 backdrop-blur-lg border border-white/20 p-6 w-full max-w-md">
            <div className="grid grid-cols-2 gap-8">
              {[
                { value: "20+", label: "Aircraft Fleet" },
                { value: "50+", label: "Certified Instructors" },
                { value: "15K+", label: "Flight Hours" },
                { value: "99%", label: "Success Rate" }
              ].map((stat, i) => (
                <div key={i} className="text-center">
                  <p className="text-3xl font-bold text-white mb-2">{stat.value}</p>
                  <p className="text-gray-300 text-sm">{stat.label}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white animate-bounce">
        <div className="flex flex-col items-center gap-2">
          <p className="text-sm font-medium">Scroll to explore</p>
          <ChevronDown className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}