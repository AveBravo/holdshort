import React from 'react';
import {
  Card,
  CardBody,
  CardHeader,
  Tabs,
  Tab,
  Input,
  Select,
  SelectItem,
  Checkbox,
  Button,
  Breadcrumbs,
  BreadcrumbItem,
} from '@nextui-org/react';
import { Home, Building2, Settings, Clock, Bell } from 'lucide-react';

const timeUnits = [
  { label: 'Hobbs Meter', value: 'hobbs' },
  { label: 'Tach Time', value: 'tach' },
  { label: 'Block Time', value: 'block' },
];

const monthOptions = Array.from({ length: 12 }, (_, i) => ({
  label: `${i + 1} Month${i === 0 ? '' : 's'}`,
  value: `${i + 1}`,
}));

export default function OrganizationSettings({ onNavigate }) {
  const [selectedTab, setSelectedTab] = React.useState("general");
  const [isPrivate, setIsPrivate] = React.useState(true);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <div className="mb-8">
        <Breadcrumbs size="lg">
          <BreadcrumbItem 
            startContent={<Home className="w-4 h-4" />}
            onPress={() => onNavigate({ page: 'home' })}
          >
            Home
          </BreadcrumbItem>
          <BreadcrumbItem 
            startContent={<Building2 className="w-4 h-4" />}
            onPress={() => onNavigate({ page: 'organization' })}
          >
            Organization
          </BreadcrumbItem>
          <BreadcrumbItem startContent={<Settings className="w-4 h-4" />}>
            Settings
          </BreadcrumbItem>
        </Breadcrumbs>
      </div>

      <Card>
        <CardHeader>
          <Tabs 
            aria-label="Organization settings"
            selectedKey={selectedTab}
            onSelectionChange={(key) => setSelectedTab(key)}
            color="primary"
            variant="underlined"
            classNames={{
              tabList: "gap-6",
              cursor: "w-full bg-primary",
            }}
          >
            <Tab
              key="general"
              title="Organization Settings"
            />
            <Tab
              key="calendar"
              title="Organization Calendar Settings"
            />
          </Tabs>
        </CardHeader>
        <CardBody>
          {selectedTab === "general" && (
            <div className="space-y-8">
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">Time Recording Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Select
                    label="Record Instructor Time by"
                    defaultSelectedKeys={["hobbs"]}
                  >
                    {timeUnits.map((unit) => (
                      <SelectItem key={unit.value} value={unit.value}>
                        {unit.label}
                      </SelectItem>
                    ))}
                  </Select>
                  <Select
                    label="Record Resource Time by"
                    defaultSelectedKeys={["hobbs"]}
                  >
                    {timeUnits.map((unit) => (
                      <SelectItem key={unit.value} value={unit.value}>
                        {unit.label}
                      </SelectItem>
                    ))}
                  </Select>
                </div>
                <Checkbox
                  isSelected={isPrivate}
                  onValueChange={setIsPrivate}
                >
                  Private organization. Hide organization from search results
                </Checkbox>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  <h3 className="text-lg font-semibold">
                    Notifications for Calendar-based Inspections
                  </h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex gap-4 items-center">
                    <Input
                      type="number"
                      label="First notification"
                      defaultValue="2"
                      className="w-24"
                    />
                    <Select
                      label="Time unit"
                      defaultSelectedKeys={["2"]}
                      className="flex-1"
                    >
                      {monthOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </Select>
                  </div>
                  <div className="flex gap-4 items-center">
                    <Input
                      type="number"
                      label="Second notification"
                      defaultValue="1"
                      className="w-24"
                    />
                    <Select
                      label="Time unit"
                      defaultSelectedKeys={["1"]}
                      className="flex-1"
                    >
                      {monthOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </Select>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  <h3 className="text-lg font-semibold">
                    Notifications for Meter-based Inspections
                  </h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex gap-4 items-center">
                    <Input
                      type="number"
                      label="First notification"
                      defaultValue="50"
                      className="w-24"
                    />
                    <span className="text-default-500 self-end mb-3">hours</span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <Input
                      type="number"
                      label="Second notification"
                      defaultValue="10"
                      className="w-24"
                    />
                    <span className="text-default-500 self-end mb-3">hours</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  color="primary"
                  className="px-8"
                >
                  Save Settings
                </Button>
              </div>
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}