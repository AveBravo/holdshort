import React from 'react';
import {
  Card,
  CardBody,
  Button,
  ButtonGroup,
  Select,
  SelectItem,
  Checkbox,
  Input,
  Breadcrumbs,
  BreadcrumbItem
} from '@nextui-org/react';
import {
  ChevronLeft,
  ChevronRight,
  Calendar,
  Home,
  Filter,
  Plus
} from 'lucide-react';

const weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const viewOptions = ['Month View', 'Week View', 'Day View', 'Stacked View', 'Dispatch View', 'Field View'];
const locations = ['All locations', 'Location 1', 'Location 2'];
const resources = ['All resources', 'Resource 1', 'Resource 2'];
const pilots = ['All pilots', 'Pilot 1', 'Pilot 2'];
const instructors = ['All instructors', 'Instructor 1', 'Instructor 2'];
const timezones = [
  { label: '(America, -10:00 HST)', value: 'HST' },
  { label: '(America, -09:00 AKST)', value: 'AKST' },
  { label: '(America, -08:00 PST)', value: 'PST' },
  { label: '(America, -07:00 MST)', value: 'MST' },
  { label: '(America, -06:00 CST)', value: 'CST' },
  { label: '(America, -05:00 EST)', value: 'EST' },
];

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = React.useState(new Date());
  const [showMaintenanceEvents, setShowMaintenanceEvents] = React.useState(true);
  const [showOnlyMyEvents, setShowOnlyMyEvents] = React.useState(false);
  const [showWaitingList, setShowWaitingList] = React.useState(true);
  const [selectedTimezone, setSelectedTimezone] = React.useState('HST');
  const [selectedLocation, setSelectedLocation] = React.useState('All locations');
  const [selectedResource, setSelectedResource] = React.useState('All resources');
  const [selectedPilot, setSelectedPilot] = React.useState('All pilots');
  const [selectedInstructor, setSelectedInstructor] = React.useState('All instructors');

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    const days = [];
    let dayCounter = 1;
    
    // Previous month days
    for (let i = 0; i < startingDay; i++) {
      const prevMonthLastDay = new Date(year, month, 0).getDate();
      days.push({
        day: prevMonthLastDay - startingDay + i + 1,
        isCurrentMonth: false
      });
    }
    
    // Current month days
    for (let i = 1; i <= daysInMonth; i++) {
      days.push({
        day: i,
        isCurrentMonth: true
      });
    }
    
    // Next month days
    const remainingDays = 42 - days.length; // 6 rows * 7 days = 42
    for (let i = 1; i <= remainingDays; i++) {
      days.push({
        day: i,
        isCurrentMonth: false
      });
    }
    
    return days;
  };

  const formatMonth = (date) => {
    return date.toLocaleString('default', { month: 'long', year: 'numeric' });
  };

  const navigateMonth = (direction) => {
    setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + direction)));
  };

  const days = getDaysInMonth(currentDate);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <div className="mb-8">
        <Breadcrumbs size="lg">
          <BreadcrumbItem startContent={<Home className="w-4 h-4" />}>
            Home
          </BreadcrumbItem>
          <BreadcrumbItem>Dashboard</BreadcrumbItem>
          <BreadcrumbItem startContent={<Calendar className="w-4 h-4" />}>
            Calendar
          </BreadcrumbItem>
        </Breadcrumbs>
      </div>

      <Card className="mb-6">
        <CardBody>
          {/* Calendar Header */}
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
            <div className="flex items-center gap-4">
              <Button
                variant="light"
                isIconOnly
                onPress={() => navigateMonth(-1)}
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <h2 className="text-xl font-semibold min-w-[200px] text-center">
                {formatMonth(currentDate)}
              </h2>
              <Button
                variant="light"
                isIconOnly
                onPress={() => navigateMonth(1)}
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>

            <ButtonGroup>
              {viewOptions.map((view) => (
                <Button
                  key={view}
                  size="sm"
                  variant={view === 'Month View' ? 'solid' : 'bordered'}
                  color={view === 'Month View' ? 'primary' : 'default'}
                >
                  {view}
                </Button>
              ))}
            </ButtonGroup>

            <Button
              color="primary"
              startContent={<Plus className="w-4 h-4" />}
            >
              Create event
            </Button>
          </div>

          {/* Filters */}
          <div className="mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Filter className="w-4 h-4" />
                  <span className="text-sm font-medium">Filter</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-2">
                  <Select
                    size="sm"
                    label="Timezone"
                    selectedKeys={[selectedTimezone]}
                    onChange={(e) => setSelectedTimezone(e.target.value)}
                  >
                    {timezones.map((timezone) => (
                      <SelectItem key={timezone.value} value={timezone.value}>
                        {timezone.label}
                      </SelectItem>
                    ))}
                  </Select>
                  <Select
                    size="sm"
                    label="Location"
                    selectedKeys={[selectedLocation]}
                    onChange={(e) => setSelectedLocation(e.target.value)}
                  >
                    {locations.map((location) => (
                      <SelectItem key={location} value={location}>
                        {location}
                      </SelectItem>
                    ))}
                  </Select>
                  <Select
                    size="sm"
                    label="Resource"
                    selectedKeys={[selectedResource]}
                    onChange={(e) => setSelectedResource(e.target.value)}
                  >
                    {resources.map((resource) => (
                      <SelectItem key={resource} value={resource}>
                        {resource}
                      </SelectItem>
                    ))}
                  </Select>
                  <Select
                    size="sm"
                    label="Pilot"
                    selectedKeys={[selectedPilot]}
                    onChange={(e) => setSelectedPilot(e.target.value)}
                  >
                    {pilots.map((pilot) => (
                      <SelectItem key={pilot} value={pilot}>
                        {pilot}
                      </SelectItem>
                    ))}
                  </Select>
                  <Select
                    size="sm"
                    label="Instructor"
                    selectedKeys={[selectedInstructor]}
                    onChange={(e) => setSelectedInstructor(e.target.value)}
                  >
                    {instructors.map((instructor) => (
                      <SelectItem key={instructor} value={instructor}>
                        {instructor}
                      </SelectItem>
                    ))}
                  </Select>
                  <Button
                    size="sm"
                    color="primary"
                    className="w-full"
                  >
                    Filter
                  </Button>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap gap-4 mt-4">
              <Checkbox
                isSelected={showMaintenanceEvents}
                onValueChange={setShowMaintenanceEvents}
                size="sm"
              >
                Show Maintenance Events
              </Checkbox>
              <Checkbox
                isSelected={showOnlyMyEvents}
                onValueChange={setShowOnlyMyEvents}
                size="sm"
              >
                Show Only My Events
              </Checkbox>
              <Checkbox
                isSelected={showWaitingList}
                onValueChange={setShowWaitingList}
                size="sm"
              >
                Show Waiting List
              </Checkbox>
            </div>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-px bg-gray-200 dark:bg-gray-700 rounded-lg overflow-hidden">
            {/* Week days header */}
            {weekDays.map((day) => (
              <div
                key={day}
                className="bg-gray-100 dark:bg-gray-800 p-2 text-center font-semibold"
              >
                {day}
              </div>
            ))}
            
            {/* Calendar days */}
            {days.map((day, index) => (
              <div
                key={index}
                className={`min-h-[120px] p-2 ${
                  day.isCurrentMonth
                    ? 'bg-background'
                    : 'bg-gray-50 dark:bg-gray-900 text-gray-400'
                }`}
              >
                <span className={`text-sm ${
                  new Date().getDate() === day.day && day.isCurrentMonth
                    ? 'bg-primary text-white w-6 h-6 rounded-full inline-flex items-center justify-center'
                    : ''
                }`}>
                  {day.day}
                </span>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Legend */}
      <Card>
        <CardBody>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-yellow-500 rounded-sm"></div>
              <span className="text-sm">Not Started</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-orange-500 rounded-sm"></div>
              <span className="text-sm">Waiting (Not Started)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-blue-500 rounded-sm"></div>
              <span className="text-sm">In Progress (Checked Out)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded-sm"></div>
              <span className="text-sm">Completed (Checked In)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded-sm"></div>
              <span className="text-sm">Maintenance</span>
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}